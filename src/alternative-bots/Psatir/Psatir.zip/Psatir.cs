using Robocode.TankRoyale.BotApi;
using Robocode.TankRoyale.BotApi.Events;
using System.Drawing;
using System;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;

// ------------------------------------------------------------------
// Psatir
// ------------------------------------------------------------------
// The bot will ram you to death if it sees you weak
// ------------------------------------------------------------------
public class Psatir : Bot
{
    // The main method starts our bot
    static void Main(string[] args)
    {
        new Psatir().Start();
    }

    // Constructor taking a BotInfo that is forwarded to the base class
    Psatir() : base(BotInfo.FromFile("Psatir.json")) { }

    // Called when a new round is started -> initialize and do some movement
    public override void Run()
    {
        BodyColor = Color.Blue;
        TurretColor = Color.Blue;
        RadarColor = Color.Black;
        ScanColor = Color.Yellow;

        // Repeat while the bot is running
        while (IsRunning)
        {
            // Tell the game that when we take move, we'll also want to turn right... a lot
            SetTurnLeft(10_000);
            // Limit our speed to 5
            MaxSpeed = 5;
            // Start moving (and turning)
            Forward(10_000);
        }
    }

    // We scanned another bot -> fire hard!
    public override void OnScannedBot(ScannedBotEvent e)
    {
        AdjustGunForBodyTurn = true;
        SetTurnLeft(0);
        Forward(0);
        double bulletPower = 2.0;
        double bulletSpeed = 20 - 3 * bulletPower;
        
        // hitung jarak, arah, dan kecepatan musuh
        double enemyDistance = Math.Sqrt(Math.Pow(e.X - X, 2) + Math.Pow(e.Y - Y, 2));
        double enemyHeading = (Math.PI / 180) * e.Direction; // ubah jadi radian
        double enemySpeed = e.Speed; // kecepatan msuuh
        double time = enemyDistance / bulletSpeed; // waktu peluru bot mencapai musuh
        
        // prediksi posisi musuh ketika peluru bot mencapai posisi musuh
        double futureX = e.X + enemySpeed * time * Math.Sin(enemyHeading);
        double futureY = e.Y + enemySpeed * time * Math.Cos(enemyHeading);
        
        // hitung arah absolut musuh relatif terhadap posisi bot pemain
        double absoluteBearing = (Math.Atan2(futureX - X, futureY - Y)) * ((180 / Math.PI));
        
        // hitung arah relatif musuh terhadap arah senjata bot pemain
        double gunTurn = normalizeBearing(absoluteBearing - GunDirection);
        
        TurnGunRight(gunTurn);
        Fire(bulletPower);
        AdjustGunForBodyTurn = false;
    }

    private double normalizeBearing(double angle) {
        while (angle > 180) angle -= 360;
        while (angle < -180) angle += 360;
        return angle;
    }

    // We hit another bot -> if it's our fault, we'll stop turning and moving,
    // so we need to turn again to keep spinning.
    public override void OnHitBot(HitBotEvent e)
    {
        var bearing = BearingTo(e.X, e.Y);
        if (bearing > -10 && bearing < 10)
        {
            Fire(3);
        }
        if (e.IsRammed)
        {
            TurnLeft(10);
        }
    }
}